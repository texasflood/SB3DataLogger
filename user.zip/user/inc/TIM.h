void TIM2_init(void);
void TIM2_IRQHandler(void);
void TIM3_init(void);
void NVIC_Configuration(void);
