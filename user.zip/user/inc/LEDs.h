void LED_init(void);
void LED_off(void);
void LED_on(void);
void timer2_init(void);
void LED_toggle(void);
