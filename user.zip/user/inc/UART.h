
void UART_init(void);
void UART_send_byte(uint8_t byte);
uint8_t UART_receive_next_byte(void);

