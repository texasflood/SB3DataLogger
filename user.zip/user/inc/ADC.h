
void ADC_init(void);
uint16_t ADC_perform_single_conversion(void);
